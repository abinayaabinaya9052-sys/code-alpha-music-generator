// MelodyAI frontend logic
const $ = (id) => document.getElementById(id);
let currentFile = null, midiData = null, synth = null, playing = false, pollTimer = null;
let toneAvailable = typeof Tone !== "undefined" && typeof Midi !== "undefined";

// ---------- helpers ----------
function toast(msg, type = "info") {
  const t = document.createElement("div");
  t.className = "toast " + type; t.textContent = msg;
  $("toasts").appendChild(t);
  setTimeout(() => t.remove(), 6000);
}
async function api(url, body) {
  const opts = body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {};
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({ ok: false, error: "Invalid server response" }));
  if (!res.ok || data.ok === false) throw new Error(data.error || "Request failed");
  return data;
}

// ---------- animated background notes ----------
(function spawnNotes() {
  const bg = $("notes-bg"), symbols = ["♪", "♫", "♩", "♬"];
  for (let i = 0; i < 22; i++) {
    const n = document.createElement("span");
    n.className = "note"; n.textContent = symbols[i % 4];
    n.style.left = Math.random() * 100 + "vw";
    n.style.fontSize = 18 + Math.random() * 30 + "px";
    n.style.animationDuration = 12 + Math.random() * 18 + "s";
    n.style.animationDelay = -Math.random() * 25 + "s";
    bg.appendChild(n);
  }
})();

// ---------- genres ----------
function fillSelect(sel, items, emptyText) {
  sel.innerHTML = "";
  if (!items.length) { sel.innerHTML = `<option value="">${emptyText}</option>`; return; }
  items.forEach(([value, label]) => sel.add(new Option(label, value)));
}
async function loadGenres() {
  try {
    const d = await api("/genres");
    $("dataset-warning").hidden = !d.dataset_empty;
    $("dataset-warning-text").textContent = d.instructions;
    fillSelect($("train-genre"), Object.entries(d.datasets).map(([g, n]) => [g, `${g} (${n} MIDI files)`]), "No datasets found");
    fillSelect($("gen-genre"), Object.entries(d.trained).map(([g, m]) => [g, `${g} (loss ${m.final_loss})`]), "No trained models yet");
    $("train-btn").disabled = d.dataset_empty;
    $("generate-btn").disabled = !Object.keys(d.trained).length;
  } catch (e) { toast(e.message, "error"); }
}

// ---------- status polling ----------
function drawLoss(loss, val) {
  const c = $("loss-chart"), g = c.getContext("2d");
  g.clearRect(0, 0, c.width, c.height);
  if (loss.length < 1) return;
  const all = loss.concat(val), max = Math.max(...all), min = Math.min(...all), span = max - min || 1;
  const line = (arr, color) => {
    g.strokeStyle = color; g.lineWidth = 2; g.beginPath();
    arr.forEach((v, i) => {
      const x = arr.length === 1 ? 10 : 10 + (i / (arr.length - 1)) * (c.width - 20);
      const y = c.height - 10 - ((v - min) / span) * (c.height - 20);
      i ? g.lineTo(x, y) : g.moveTo(x, y);
    });
    g.stroke();
  };
  line(loss, "#a855f7"); if (val.length) line(val, "#38bdf8");
  $("loss-caption").textContent = `Loss (purple)${val.length ? ", validation (blue)" : ""} – latest: ${loss[loss.length - 1]}`;
}
let lastState = "idle";
async function pollStatus() {
  try {
    const s = await api("/status");
    $("status-text").textContent = s.error ? `Error: ${s.error}` : s.message;
    $("progress").style.width = s.progress + "%";
    drawLoss(s.loss_history || [], s.val_loss_history || []);
    const busy = s.state === "training" || s.state === "generating";
    $("train-btn").disabled = busy; $("generate-btn").disabled = busy && s.state === "training";
    if (lastState === "training" && s.state === "idle") { toast(s.message, "success"); loadGenres(); }
    if (lastState === "training" && s.state === "error") toast(s.error, "error");
    lastState = s.state;
    if (!busy && pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  } catch (e) { /* server may be busy; try again */ }
}
function startPolling() { if (!pollTimer) pollTimer = setInterval(pollStatus, 1000); }

// ---------- training ----------
$("train-btn").onclick = async () => {
  try {
    const genre = $("train-genre").value;
    if (!genre) return toast("No dataset available. Add MIDI files first.", "error");
    await api("/train", {
      genre, epochs: +$("epochs").value, batch_size: +$("batch").value,
      seq_len: +$("seqlen").value, learning_rate: +$("lr").value,
    });
    lastState = "training"; toast("Training started.", "success");
    startPolling(); pollStatus();
  } catch (e) { toast(e.message, "error"); }
};

// ---------- generation ----------
$("length").oninput = () => ($("len-val").textContent = $("length").value);
$("temperature").oninput = () => ($("temp-val").textContent = $("temperature").value);
$("generate-btn").onclick = async () => {
  const btn = $("generate-btn");
  try {
    const genre = $("gen-genre").value;
    if (!genre) return toast("Train a model first.", "error");
    btn.disabled = true; btn.querySelector(".spinner").hidden = false;
    btn.querySelector(".label").textContent = "Generating...";
    lastState = "generating"; startPolling();
    const r = await api("/generate", {
      genre, length: +$("length").value, temperature: +$("temperature").value, seed: $("seed").value,
    });
    toast(`Generated ${r.filename} (seed ${r.seed})`, "success");
    await selectTrack(r.filename);
    loadHistory();
  } catch (e) { toast(e.message, "error"); }
  finally {
    btn.disabled = false; btn.querySelector(".spinner").hidden = true;
    btn.querySelector(".label").textContent = "Generate Music";
    pollStatus();
  }
};

// ---------- player ----------
async function selectTrack(filename) {
  stopPlayback();
  currentFile = filename; midiData = null;
  $("now-playing").textContent = filename;
  const dl = $("download-btn"); dl.href = "/download/" + filename; dl.classList.remove("disabled");
  if (!toneAvailable) {
    $("player-msg").textContent = "Browser playback is unavailable (the Tone.js / @tonejs/midi libraries could not be loaded – check your internet connection). You can still download the MIDI file and play it in any MIDI player.";
    return;
  }
  try {
    const buf = await (await fetch("/download/" + filename)).arrayBuffer();
    const Cls = window.Midi.Midi || window.Midi;
    midiData = new Cls(buf);
    $("play-btn").disabled = false; $("player-msg").textContent = "";
  } catch (e) { $("player-msg").textContent = "Could not load the MIDI for playback: " + e.message; }
}
function stopPlayback() {
  if (!toneAvailable) return;
  Tone.Transport.stop(); Tone.Transport.cancel(); playing = false;
  $("play-btn").textContent = "▶ Play"; $("play-progress").style.width = "0%";
}
$("play-btn").onclick = async () => {
  if (!midiData) return;
  await Tone.start();
  if (playing) { Tone.Transport.pause(); playing = false; $("play-btn").textContent = "▶ Resume"; return; }
  if (Tone.Transport.state === "paused") { Tone.Transport.start(); playing = true; $("play-btn").textContent = "⏸ Pause"; return; }
  if (!synth) synth = new Tone.PolySynth(Tone.Synth, { maxPolyphony: 16 }).toDestination();
  Tone.Transport.cancel();
  midiData.tracks.forEach((track) => track.notes.forEach((n) =>
    Tone.Transport.schedule((time) => synth.triggerAttackRelease(n.name, n.duration, time, n.velocity), n.time)));
  Tone.Transport.schedule(() => stopPlayback(), midiData.duration + 0.5);
  Tone.Transport.start("+0.1"); playing = true; $("play-btn").textContent = "⏸ Pause";
  (function tick() {
    if (Tone.Transport.state === "stopped") return;
    $("play-progress").style.width = Math.min(100, (Tone.Transport.seconds / midiData.duration) * 100) + "%";
    requestAnimationFrame(tick);
  })();
};

// ---------- history ----------
async function loadHistory() {
  try {
    const items = await api("/history");
    const body = $("history-body");
    if (!items.length) { body.innerHTML = '<tr><td colspan="4">Nothing generated yet.</td></tr>'; return; }
    body.innerHTML = "";
    items.forEach((it) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${it.filename}</td><td>${it.created}</td><td>${it.size_kb} KB</td>
        <td><button data-f="${it.filename}">Load</button> <a href="/download/${it.filename}" style="color:#c4b5fd">Download</a></td>`;
      tr.querySelector("button").onclick = () => selectTrack(it.filename);
      body.appendChild(tr);
    });
  } catch (e) { toast(e.message, "error"); }
}

$("refresh-btn").onclick = loadGenres;
loadGenres(); loadHistory(); pollStatus();
if (!toneAvailable) $("player-msg").textContent = "Browser playback libraries not loaded (internet required). Downloads still work.";
