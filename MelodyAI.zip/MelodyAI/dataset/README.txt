Put MIDI files (.mid / .midi) in sub-folders named after the genre:

  dataset/classical/*.mid
  dataset/jazz/*.mid

Any folder name made of letters, digits, "_" or "-" becomes a genre in the app.
Only use MIDI files you are legally allowed to use (see README.md).
